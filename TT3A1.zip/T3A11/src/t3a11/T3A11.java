package t3a11;

import java.util.Scanner;

public class T3A11 {

   public static void main(String[] args) {
       procesar();
    }
    public static void procesar() {
        Scanner scanner = new Scanner (System.in);
        Calificaciones calificaciones = new Calificaciones();
        
        System.out.printf("Nombre:");
        String nombre  = scanner.nextLine();
        calificaciones.setNombre(nombre);
        
        System.out.print("Apellido Paterno:");
        String apellidoPaterno = scanner.nextLine();
        calificaciones.setApellidoPaterno(apellidoPaterno);
        
        System.out.print("Apellido Materno:");
        String apellidoMaterno = scanner.nextLine();
        calificaciones.setApellidoMaterno(apellidoMaterno);
        
        System.out.print("Grupo:");
        String grupo = scanner.nextLine();
        calificaciones.setGrupo(grupo);
        
        System.out.print("Carrera:");
        String carrera = scanner.nextLine();
        calificaciones.setCarrera(carrera);
        
        System.out.print("Nombre de Asignatura 1:");
        String nombreAsignatura = scanner.nextLine();
        calificaciones.setNombreAsignatura1(nombreAsignatura);
        
        
        System.out.print("Nombre de Asignatura 2:");
        String nombreAsignatura2 = scanner.nextLine();
        calificaciones.setNombreAsignatura2(nombreAsignatura);
        
        System.out.print("Calificacion Asignatura 1:");
        float calificacion1 = scanner.nextFloat();
        calificaciones.setCalificacion1(calificacion1);
        
        System.out.print("Calificacion Asignatura 2:");
        float calificacion2 = scanner.nextFloat();
        calificaciones.setCalificacion2(calificacion2);
        
        System.out.println(calificaciones.toString());
        
        
    
    }
    
}

