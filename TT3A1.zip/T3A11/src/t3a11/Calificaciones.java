package t3a11;

import java.util.Scanner;

public class Calificaciones {

    private String nombre;
    private String apellidoPaterno;
    private String apellidoMaterno;
    private String grupo;
    private String carrera;
    private String nombreAsignatura1;
    private String nombreAsignatura2;
    private float calificacion1;
    private float calificacion2;
    private float promedio;

    public Calificaciones() {

    }

    public Calificaciones(String nombre, String apellidoPaterno, String apellidoMaterno, String grupo, String carrera, String nombreAsignatura1, String nombreAsignatura2, float calificacion1, float calificacion2, float promedio) {
        this.nombre = nombre;
        this.apellidoPaterno = apellidoPaterno;
        this.apellidoMaterno = apellidoMaterno;
        this.grupo = grupo;
        this.carrera = carrera;
        this.nombreAsignatura1 = nombreAsignatura1;
        this.nombreAsignatura2 = nombreAsignatura2;
        this.calificacion1 = calificacion1;
        this.calificacion2 = calificacion2;
        this.promedio = promedio;
    }

    @Override
    public String toString() {
        return "Calificaciones" + "\n" + "Nombre del alumno:" + nombre + " " + apellidoPaterno + " " + apellidoMaterno + "\n" + " Grupo:" + grupo + "          " + " Carrera:" + carrera + "\n" + "\n" + " Nombre Asignatura 1:" + nombreAsignatura1 + "\n" + " Nombre Asignatura 2:" + nombreAsignatura2 + "\n" + " Calificacion Materia 1:" + calificacion1 + "\n" + " Calificacion Materia 2:" + calificacion2 + "\n" + " Promedio:" + (calificacion1 + calificacion2) / 2;
    }

    public double getPromedio() {
        return promedio;
    }

    public void setPromedio(int promedio) {
        this.promedio = promedio;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidoPaterno() {
        return apellidoPaterno;
    }

    public void setApellidoPaterno(String apellidoPaterno) {
        this.apellidoPaterno = apellidoPaterno;
    }

    public String getApellidoMaterno() {
        return apellidoMaterno;
    }

    public void setApellidoMaterno(String apellidoMaterno) {
        this.apellidoMaterno = apellidoMaterno;
    }

    public String getGrupo() {
        return grupo;
    }

    public void setGrupo(String grupo) {
        this.grupo = grupo;
    }

    public String getCarrera() {
        return carrera;
    }

    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }

    public String getNombreAsignatura1() {
        return nombreAsignatura1;
    }

    public void setNombreAsignatura1(String nombreAsignatura1) {
        this.nombreAsignatura1 = nombreAsignatura1;
    }

    public String getNombreAsignatura2() {
        return nombreAsignatura2;
    }

    public void setNombreAsignatura2(String nombreAsignatura2) {
        this.nombreAsignatura2 = nombreAsignatura2;
    }

    public float getCalificacion1() {
        return calificacion1;
    }

    public void setCalificacion1(float calificacion1) {
        this.calificacion1 = calificacion1;
    }

    public float getCalificacion2() {
        return calificacion2;
    }

    public void setCalificacion2(float calificacion2) {
        this.calificacion2 = calificacion2;
    }

}
